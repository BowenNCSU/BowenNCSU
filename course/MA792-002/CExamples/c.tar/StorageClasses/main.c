/* File CExamples/StorageClasses/main.c
   Compile and run this program as

   gcc -c bar.c       produces bar.o object file
   gcc bar.o main.c   compiles and links the two files
   a.out

*/
const int MAXIMUM = 100;
/* MAXIMUM cannot be changed in this file */
extern int MINIMUM;
/* storage is allocated somewhere else (in file "bar.c") */

#define MAX 100
/* MAX is replaced by 100 by the preprocessor */

extern int bar(int*);
/* this is the prototype; the function is compiled
   separately (see "bar.c"); extern is default */

static int foo(const int *iptr)
/* static means foo is not known outside this file;
   const in parameter type indicates that the function
   cannot change the value */
{auto int j = 0;
 /* auto is default; will be allocated and initialized at
    every call */
 static int k = 0;
 /* static means that value is allocated and initialized
    just once */
 extern const int MAXIMUM;
 /* this is redundant, since MAXIMUM is allocated in this file; see MINIMUM */
 j = j + MINIMUM + bar(&MAXIMUM); /* Here is a problem: MAXIMUM is const,
                                     while bar has a non-constant int* arg,
                                     thus allowing bar to change that value;
                                     gcc produces a warning only. */
 k = k + MAX + *iptr;
 printf("j == %d, k == %d\n", j, k);
 return j+k;
}

void main(void)
{int a = 1;
 MINIMUM = -50;
 printf("%d\n", foo(&a));
 printf("%d\n", bar(&a));
 printf("%d\n", foo(&a));
}
