/* File CExamples/StorageClasses/bar.c */
/* both MINIMUM and bar are names linkable from other files */
int MINIMUM;

int bar(int *iptr)
{extern const int MAXIMUM;
 iptr = iptr + 1; /* increment the address of the argument! */
 return(MAXIMUM);
}
