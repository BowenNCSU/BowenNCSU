/* File: CExamples/OO_pgm_in_C/stack.c */
#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

void print_stack(stack s)
/* print the stack; note that this function should work
   independently of the underlying data structure, i.e.,
   it is a generic function */
{stackptr s2ptr; /* store the popped elements */
 int i;
 s2ptr = (*s.clone)(s.objptr);
 printf("Stack contents: ");
 while( !(*s2ptr->is_empty)(s2ptr->objptr) )
   {i = (*s2ptr->pop)(s2ptr->objptr);
    printf("%2d ", i);
   };
 printf(" bottom\n"); fflush(stdout);
 delete_stack(s2ptr);
}/* end print_stack */
