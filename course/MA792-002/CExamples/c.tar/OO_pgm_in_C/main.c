/* File: CExamples/OO_pgm_in_C/main.c */
/* See also: ../C++Examples/Stacks/ for the C++ version
             ../JavaExampels/Stacks/ for the Java version
*/

#include <stdio.h>
#include "stack.h"

int main(void)
/* Test the stack */
/* Note: this function is also generic and can be linked
         with any implementation of stack */
{int i;
 stackptr sptr;

 sptr = new_stack();
 print_stack( *sptr );
 for (i=1; i < 6; i++)
     { printf("Pushing %d \n", i);
       (*sptr->push)( i, sptr->objptr );
       print_stack( *sptr );
     }
 
 for (i=0; i < 3; i++)
     { printf("Popping %d \n",
              (*sptr->pop)( sptr->objptr ) );
       print_stack( *sptr );
     }
 delete_stack(sptr);
 return 0;
}
