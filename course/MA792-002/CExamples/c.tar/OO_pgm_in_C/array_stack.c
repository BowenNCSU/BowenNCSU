/* File: CExamples/OO_pgm_in_C/array_stack.c */
#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

/* This is the Data Structure used to implement the stack:
   array[top-1] is the last element entered, array[0] the first */
typedef struct array_stack { int top;
                             int array[20];
                           } AS, *ASptr;

stackptr new_stack()
/* This function is the interface from the abstract object to the D.S.
   it creates a stack and the array_stack */
{stackptr sptr;
 /* declare the functions that will implement the stack operations */
 int  array_isempty(void*);
 void array_push   (int, void*);
 int  array_pop    (void*);

 stackptr array_new (void*);
 void array_delete (void*);
 stackptr array_clone (void*);

 /* allocate memory for the stack */
 sptr = (stackptr)malloc(sizeof(stack));

 /* set the function pointers to array functions */
 sptr->is_empty = array_isempty;
 sptr->push     = array_push;
 sptr->pop      = array_pop;
 sptr->clone    = array_clone;

 /* allocate memory for the array_stack and initialize */
 sptr->objptr = malloc(sizeof(AS));
 ((ASptr)sptr->objptr)->top = 0;
 /* must typecast as ASptr before selection: objptr has type void*;
    note: conversion from and to type void* is permissible for all pointers */
 return sptr;
}/* end new_stack */


void delete_stack( stackptr sptr )
/* Assumes that sptr is the result of new_stack */
{free(sptr->objptr); free(sptr);}/* end delete_stack */

/* The following three functions define the array_stack operations */
int array_isempty(void *asptr)
{return( ((ASptr)asptr)->top == 0 );
}/* end is_empty */


void array_push(int i, void *asptr)
{ASptr asptr2;
 asptr2 = (ASptr)asptr;
 /* no check for overflow */
 asptr2->array[asptr2->top++] = i;
}/* end array_push */


int array_pop(void *asptr)
{ASptr asptr2;
 asptr2 = (ASptr)asptr;
 /* no check for underflow */
 return asptr2->array[--asptr2->top];
}/* end array_pop */

stackptr array_clone (void* asptr)
{stackptr sptr;
 sptr = (stackptr)malloc(sizeof(stack));
 /* set the function pointers to array functions */
 sptr->is_empty = array_isempty;
 sptr->push     = array_push;
 sptr->pop      = array_pop;
 sptr->clone    = array_clone;

 sptr->objptr = (ASptr)malloc(sizeof(AS));
 *((ASptr)sptr->objptr) = *((ASptr)asptr); /* field-wise assign */
 return sptr;
}
