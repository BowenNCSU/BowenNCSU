/* File: CExamples/OO_pgm_in_C/stack.h */

/* This is the abstract data object; initialize by calling new_stack
                                     remove by calling delete_stack */
typedef struct stackstruct {  void *objptr; /* address of data struct. */
                              /* abstract methods */
                              int (*is_empty)(void*);
                              void(*push)    (int, void*);
                              int (*pop)     (void*);
                              /* object manipulation */
                              struct stackstruct* (*clone) (void*); /* make a copy */
                           } stack, *stackptr;
  
extern void print_stack(stack s);

/* these functions are specific to the data structure used:
   therefore, there can only be one data structure used by
   a computation, which is a restriction */
extern stackptr new_stack(void);
extern void delete_stack(stackptr);
