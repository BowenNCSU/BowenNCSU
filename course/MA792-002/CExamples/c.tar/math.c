#include <math.h>
#include <stdio.h>
/* compile this program as "gcc -Wall -ansi math.c -lm" */
void main(void)
{printf("2 to the 10th == %d\n", (int)floor(pow(2,10)+0.5));}
