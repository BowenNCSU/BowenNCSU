/* File: CExamples/Lists/main.c */

#include "prof.h"
void printlist(PROFLIST Cptr)
{PROFLIST curr;
   printf("\nList contains:\n");
   for(curr = Cptr;
       curr != NULL;
       curr = curr->next)
       printf("%s %s\n", curr->prof.lname, curr->prof.fname);
}

int main(void)
{PROF berry = {"Berry", "Jon", '?', 10.0, 1, 3.5},
      blythes = {"Blythes", "Stephen", '?', 10.0, 1, 3.5},
      kaltofen = {"Kaltofen", "Erich", 'L', 40.0, 4, 3.0};
 /* note the initializations for the structures */
 PROFLIST L = NULL;

 hire(&L, blythes); printlist(L);
 hire(&L, kaltofen); printlist(L);
 hire(&L, berry); printlist(L);

 fire(&L, "Kaltofen"); printlist(L);
 fire(&L, "Berry"); printlist(L);
 return 0;
}
