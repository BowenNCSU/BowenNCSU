/* File: CExamples/Lists/fire.c */
#include "prof.h"

int fire( PROFLIST *Cptrptr
         ,char badprof[]
        )
{/* remove element from sorted list;
    return 0 if removal was successful;
    reset *Cptrptr if first cell in remaining list
    has changed (``call by reference'') */

   PROFLIST curr, prev; int found;
   
   for(curr = *Cptrptr, prev = NULL;
       curr != NULL;
       prev = curr, curr = curr->next)
      {found = strcmp(badprof, curr->prof.lname);
       if (found <= 0) break;
      }
   
   if(curr == NULL || found < 0) return 1; /* not found */
   
   /* jump over curr, which contains record of badprof */
   if (prev == NULL)
      *Cptrptr = curr->next; /* badprof is first on list */
   else prev->next = curr->next;
   
   free(curr);
   return 0;
} /* end fire */
