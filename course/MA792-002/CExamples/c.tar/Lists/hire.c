/* File: CExamples/Lists/hire.c */
#include "prof.h"

int hire(PROFLIST *Cptrptr, PROF goodprof)
{/* insert goodprof in alphabetic order;
   returns 0 if successful, 1 if goodprof already there,
   -1 if no more memory */

   PROFLIST curr, prev, newc; int found;

   for(curr = *Cptrptr, prev = NULL;
       curr != NULL;
       prev = curr, curr = curr->next)
      {found = strcmp(goodprof.lname, curr->prof.lname);
       if (found <= 0) break;
      }

   if(curr != NULL && found==0) return 1; /* already there */

   /* create new cell */
   newc = (PROFLIST)malloc(sizeof(PROFLISTCELL));
   if(newc == NULL) return -1; /* out of memory */
   newc->prof = goodprof;

   /* link into list */
   if(prev==NULL)
      *Cptrptr = newc;
   else prev->next = newc;
   newc->next = curr;
   return 0;
}
