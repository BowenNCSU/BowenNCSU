/* File: CExamples/Lists/hire2.c */
#include "prof.h"

int hire2( PROFLIST *Cptrptr
          ,PROF *goodprofptr)
{/* insert *goodprofptr in alphabetic order;
   returns 0 if successful, 1 if *goodprofptr already there,
   -1 if no more memory */

   PROFLIST curr, prev, newc; int found;

   for(curr = *Cptrptr, prev = NULL;
       curr != NULL;
       prev = curr, curr = curr->next)
      {found = strcmp(goodprofptr->lname, curr->prof.lname);
       if (found <= 0) break;
      }

   if(curr != NULL && found==0) return 1; /* already there */

   /* create new cell */
   newc = (PROFLIST)malloc(sizeof(PROFLISTCELL));
   if(newc == NULL) return -1; /* out of memory */

   /* because we had the pointer arg, we save one memcpy
      of the structure, that from the argument into the parameter */
   newc->prof = *goodprofptr;

   /* link into list */
   if(prev==NULL) *Cptrptr = newc;
   else prev->next = newc;
   newc->next = curr;
   return 0;
} /* end hire2 */
