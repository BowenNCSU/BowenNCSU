/* File: CExamples/Lists/main.c */
/* uses reference arguments to hire */
#include "prof.h"

void printlist(PROFLIST Cptr)
{PROFLIST curr;
   printf("\nList contains:\n");
   for(curr = Cptr;
       curr != NULL;
       curr = curr->next)
       printf("%s %s\n", curr->prof.lname, curr->prof.fname);
} /* end printlist */

void main(void)
{PROF  caviness = {"Caviness", "Bob",     'F', 100.0, 1, 4.5}
      ,eberly   = {"Eberly",   "Wayne",   'M',  70.0, 2, 3.4}
      ,kaltofen = {"Kaltofen", "Erich",   'L',  50.0, 1, 3.0}
      ,saunders = {"Saunders", "Benjamin",'D',  95.0, 2, 3.5}
      ; /* note the initializations for the structures */
 PROFLIST L = NULL;
 
 hire2(&L, &eberly); printlist(L);
 hire2(&L, &saunders); printlist(L);
 hire2(&L, &kaltofen); printlist(L);
 hire2(&L, &caviness); printlist(L);

 fire(&L, "Eberly"); printlist(L);
 fire(&L, "Kaltofen"); printlist(L);
 fire(&L, "Caviness"); printlist(L);
} /* end main */
