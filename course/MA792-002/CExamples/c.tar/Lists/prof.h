/* File: CExamples/Lists/prof.h */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef
struct prof {
   char lname[20];
   char fname[10];
   char MI;
   double salary;
   int rank;
   float TPA; /* ``teaching point average'' */  
} PROF, *PROFPTR;

typedef
struct proflistcell {
   PROF prof; /* note: no conflict with struct prof */
   struct proflistcell *next;
} PROFLISTCELL, *PROFLIST;
/* Note: here a list is a pointer to the first cell */

int fire(PROFLIST*, char*);
int hire(PROFLIST*, PROF);
int hire2(PROFLIST*, PROF*);
