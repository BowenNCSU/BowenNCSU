/* File CExamples/Recursion/main.c */

#include <stdio.h>
extern long int combin(int, int);

/* program to test combin.c and combin2.c; compile as

      gcc combin2.c main.c

*/
int main(void)
{ int i, k;
  printf("Enter first pair of arguments for combination: ");
  fflush(stdout);
  while(scanf("%d%d", &i, &k) == 2)
    { printf("combin(%4d,%4d)=%ld\n", i, k, combin(i,k));
      printf("Enter next pair of arguments for combination: ");
      fflush(stdout);
    };
  return 0;
}
