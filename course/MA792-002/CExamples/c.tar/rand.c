#include <stdio.h>
#include <stdlib.h>


int main(void){
 int i;
 srand(101);
 for (;;)
   {for (i=0; i<30; i++)
        /* print a random bit */
        printf("%1d ", 1 & rand());
    printf("\n");
   }
 return 0;
}
